---
name: "deepseek-harness"
description: "Technical and strategic analysis of DeepSeek Harness (DSH) for Kuaizi's FDE delivery model"
---

- Doing deep technical and strategic work analyzing DeepSeek Harness (DSH), its open-source agent runtime architecture, directly from source code
- Drawing implications for Kuaizi's FDE delivery model — building dynamic feedback loops, capability asset packages, and shared-core/customer-specific patch-layer architecture
