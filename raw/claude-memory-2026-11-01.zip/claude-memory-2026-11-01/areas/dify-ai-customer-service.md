---
name: "dify-ai-customer-service"
description: "Building AI customer service workflows on Dify for beauty and maternal/infant brand clients"
---

- Building and iterating AI customer service workflows on Dify for beauty and maternal/infant brand clients (Aptamil, Sulwhasoo, Amorepacific)
- Work includes complex debugging, architectural redesigns, compliance pre-gating, unclosed-intent tracking, and client-facing deliverables explaining "harness engineering" concepts
