---
name: "douyin-qianchuan-fde-solution"
description: "筷子 FDE 解决方案 — 抖音千川投流视频生成闭环场景（面向客户的介绍方案）及筷子 MCP 清单位置"
---

- 在做一份基于筷子 MCP 能力的抖音千川投流视频生成完整方案；判断这个场景是刚需、闭环的
- 方案读者是客户，定位为"筷子 FDE 解决方案"（抖音投放闭环的 FDE 介绍）；先只做到一期；PPT 形式、用筷子模版；数字留空
- 筷子 MCP 清单看原子能力平台：https://dev-fde.kuaizi.co/fde-atom-demo-web/
- 相关：[[fde-strategy]]、[[workbuddy-open-platform]]、[[kuaizi-mcp-open]]
