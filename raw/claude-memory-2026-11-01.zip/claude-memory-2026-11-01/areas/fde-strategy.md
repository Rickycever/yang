---
name: "fde-strategy"
description: "筷子 FDE 增长战略的目标与原则 — KP 积分消耗作为商业成功目标、团队已组建、探索议题与决策方式"
---

- FDE is a core growth strategy at Kuaizi, driven by company management; FDE team has been assembled (as of Sept 2026)
- Business success target: more consumption of Kuaizi KP credits (atomic services, video tokens, high-value skills); ultimate goal is customer-success-driven scaled profitability
- Exploring: rollout path, business targets, team configuration, product atomic capabilities, front-end delivery interface and efficiency
- Principles: integrity, customer-success oriented; core decisions follow what/why/how with quantifiable goals; stay tech-aware but focus on commercial SOP over chasing tech; partner with successful clients
- Uses an agent task group to work on FDE strategy
- Recruiting an FDE-direction project manager (Sept 2026); role must also sediment common client-delivery components into company atomic capabilities; requires 5+ yrs delivery and 1+ yr AI project experience
- 所有 FDE 项目的内部确认点：MCP 服务的正式可用时间、交付资源的确认（先于对外承诺）
- 计划把 FDE 成功客户案例沉淀为行业 Skill（诊断规划 + 落地执行），复制给其他同类客户，并在对外案例宣传中使用这一说法（2026-10）
- 筷子现有三套 SaaS：编排剪投主平台、丽帧、推你；未来 FDE 逻辑是三平台能力下沉为原子服务、统一对外推 KP MCP，打通形成视频商业服务（2026-10）
- 生产和分发都用原子能力实现；三套 SaaS 是过渡阶段，未来可能淡化；现有 SaaS 客户不强制迁移、并行运行，需要时再做数据迁移
- 客户用自有 harness（WorkBuddy、Codex 等）接 MCP 时，仍需 GUI 环境管理上下文（素材库、数据、微调）并连接上下游企业工作流；该 GUI/上下文中台可能私有化部署到客户环境，也可能是 SaaS
- 筷子与上影昊浦有合作：把视频商业环境结合最优算力组合，提供一套 harness 环境，协同上下游伙伴共创 skill 和影视作品（2026-10）
- 筷子在视频商业领域最看重的是从 brief → 策略 → 生成 → 分发 → 数据分析的全流程数据驱动闭环（2026-10）
- FDE 交付方法论 KUAIZI 英文全称：K Kickoff（活动策略）· U Unit Goals（目标拆解）· A Angle（选题策划）· I Insight（爆款解析）· Z Zero-to-Scale（规模复制）· I Ignite & Iterate（引爆迭代）
