---
name: "geo-content-distribution-system"
description: "筷子 GEO 短视频内容分发系统的产品设计与关键决策(客户可自助、央视网 + KOC 双渠道)"
---

- 在为筷子设计 GEO 短视频内容分发系统,面向品牌客户,与 [[geo-gem-research]] 同一方向
- 两条内容生产路径:客户上传素材做 AI 拆条混剪,或用客户预制 Skill/提示词脚本走 AIGC 生成
- 分发渠道两类:央视网特定页面(暂定 API 对接)与 KOC 矩阵号(用筷子自有账号资源)
- 生产能力用 Seedance 2.0
- 客户自助运营,初期 FDE 陪跑一周
- 效果回测放二期
- 一期只做前端界面交互和选择,不做对话式 Agent
- SOP 背后对应筷子已有的原子服务,由 prompt 和 skill 驱动,是固定 SOP 约束而非 Agent 自由发挥
- 二期对话式交互不自建,计划接入类似腾讯 WorkBuddy 的外部宿主系统(见 [[workbuddy-open-platform]])
