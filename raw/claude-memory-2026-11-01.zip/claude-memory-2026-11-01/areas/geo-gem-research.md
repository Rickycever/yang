---
name: "geo-gem-research"
description: "Research into the GEO/GEM (Generative Engine Optimization/Marketing) market"
---

- Researching the GEO/GEM (Generative Engine Optimization/Marketing) market
- Particular focus on video citation patterns in Doubao (豆包)
- Has produced a structured query-testing framework and Excel workbook
