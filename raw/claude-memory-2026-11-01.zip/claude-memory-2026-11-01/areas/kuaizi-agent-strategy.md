---
name: "kuaizi-agent-strategy"
description: "Strategic planning for Kuaizi's evolution toward an AI video commerce intelligent agent system"
---

- Conducted a strategic planning session for Kuaizi's evolution toward an AI video commerce intelligent agent system
- Produced investor-facing materials: HTML one-pager, Excel market model, PRD increments, product strategy document
- Materials cover a three-pool value model, two-shell architecture, FDE growth paths, and compute-layer partnership strategy
- Built a "战略可视化全集" HTML visualization collection covering FDE delivery management, Adobe strategy benchmarking, and competitive analysis
- Reviewed two contracts: Shanghai Film "昊帧" AI film agent; Volcano Engine Seedance supplement
- Earlier designed a productized enterprise employee-agent collaboration platform for Kuaizi — full PRD with RBAC permission matrix, TaskCard state machine, API list, and UI prototypes
- Conducted extensive multi-agent platform competitive research (LangGraph, AutoGen, CrewAI, Coze, Dify, Salesforce Agentforce)
