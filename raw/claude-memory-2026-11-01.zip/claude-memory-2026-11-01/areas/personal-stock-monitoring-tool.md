---
name: "personal-stock-monitoring-tool"
description: "Real-time A-share/HK stock monitoring tool built by Ricky"
---

- Built a real-time A-share/HK stock monitoring tool (HTML, Tencent API) with portfolio diagnostics and cluster analysis views
- Has built personal stock monitoring tools
