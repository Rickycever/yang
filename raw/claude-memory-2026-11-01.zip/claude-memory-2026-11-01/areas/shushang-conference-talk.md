---
name: "shushang-conference-talk"
description: "Ricky 在数商大会的演讲准备 — 主题\"视频商业的 token 化跃迁\"，呼应大会关键词\"数据链接\""
---

- Ricky 在准备数商大会 25 分钟演讲，主题"视频商业的 token 化跃迁"，需呼应大会核心关键字"数据链接"，用大会模版做 PPT（2026-10）
- 核心思路：视频商业 = 视频内容 + 数据 → 商业 ROI；token 化跃迁 = 从用 token 生产到数据驱动的智能 token 路由（经济、稳定、适配、可审计）
