---
name: "video-commerce-agent-team"
description: "Ricky 组建的视频商业 agent 团队 — 现有编导策划、视频生成两个 agent"
---

- Ricky 组建了一个视频商业 agent 团队，现有编导策划和视频生成两个 agent（2026-10）
- 相关：[[kuaizi-mcp-open]]、[[fde-strategy]]
