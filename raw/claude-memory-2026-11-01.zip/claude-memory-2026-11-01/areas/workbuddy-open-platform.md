---
name: "workbuddy-open-platform"
description: "筷子接入腾讯 WorkBuddy 开放平台（连接器/MCP）的探索"
---

- 在探索把筷子的 MCP 服务接入腾讯 WorkBuddy 开放平台，方向是连接器（Connector）
- 筷子内部已有一套 MCP 服务工具，通过自建的 mcp-lab 调试台查看（dev-kclaw.kuaizi.co/mcp-lab）
- 相关：[[kuaizi-agent-strategy]]
