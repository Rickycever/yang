---
name: "winder"
description: "CEO referenced in Kuaizi work"
---

- Winder (陈万锋), CEO — key colleague referenced in Kuaizi strategic work
