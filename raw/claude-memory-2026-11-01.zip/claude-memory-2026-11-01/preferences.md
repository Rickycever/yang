---
name: "preferences"
description: "How Ricky wants Claude to work — output and file delivery conventions"
---

- 交付文件名要带版本号,每次修改后版本号递增,便于区分最新版
- 输出 Word 文档时一律调用 docx 技能来制作（排版要精致）,不要直接从在线文档导出
- 以后做 PPT 一律用微软雅黑字体（中英文统一）
- 涉及筷子科技模版的 PPT，用 2026-10 Kuaizi Atom 路演那版（筷子ppt模版202607.pptx 深色风格，成品见 ~/Desktop/CC/数商大会/Kuaizi_Atom原子能力路演_v2.pptx）；筷子科技介绍就用那几页：全球运行的视频商业智能体系统数据页（人像授权 20 万+）、把领先模型变成持续运行的视频商业能力、把「生成」变成生意、各产品组成视频商业智能体系统（丽帧/主平台/推你 + FDE）、联系我们
