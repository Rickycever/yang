---
name: "profile"
description: "Who Ricky is — role, employer, and what he works on"
---

- Name: Ricky
- Commercialization growth lead at 筷子科技 (Kuaizi Technology), an AI-powered video commerce company
- Kuaizi operates an FDE (Forward Deployed Engineer + Final Delivery Excellence) model with enterprise clients including Eli Lilly, Mengniu, and Haidilao
- Leads the FDE function at Kuaizi
- Kuaizi targets global users, serving both overseas and domestic (China) clients
- Work spans product strategy, business development, enterprise AI delivery, and client-facing content production involving AI video generation
- Prior affiliation with 明略科技 (Minglue/Minstrel Technology)
- Describes himself as not a technical person (我不是技术人员)
- Describes himself as someone who doesn't know video shooting/production craft (不懂视频拍摄)
