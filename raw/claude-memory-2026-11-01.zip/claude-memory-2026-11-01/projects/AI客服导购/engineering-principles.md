---
name: "engineering-principles"
description: "Hard-won technical rules for the Dify/ChatFlow workflow — determinism, retrieval, parsing, chunking, and change governance"
---

## Architecture rules

- Deterministic logic belongs in Code nodes, never LLM nodes: price calculations, order ID validation, keyword matching, and promotional rule lookups must be deterministic and reproducible.
- Single source of truth for promotions: real-time API only, never the knowledge base — hardcoding promotional rules on the AI side is a known failure pattern.
- Brand-specific config is layered as overrides on a shared base; multi-brand scalability requires a shared template with override layers, not per-client forks.
- Health symptom escalation is non-negotiable: abnormal symptom queries must route to human agents, never be handled autonomously by the LLM.

## Retrieval and prompting

- Retrieval query must use the rewritten query, not raw input: `query_rewrite.text`, not `sys.query` — raw input pollutes multi-turn retrieval quality.
- Chunk size matters for embedding quality: per-question individual chunks (~116 chars) are too short; topic-merged chunks (~648 chars) with structured separators work significantly better.
- "Answer first, then ask one follow-up question" is preferred over completeness-check gate patterns that block responses until all slots are filled.

## Known technical gotchas

- Python `\b` word boundary fails on Chinese text: PII masking regex must use `(?<!\d)\d{19}(?!\d)` because Chinese characters are treated as `\w` in Unicode.
- DeepSeek `<think>` tags break downstream JSON parsing — requires a regex strip before `json.loads()`.

## Change governance and editing

- Workflow change governance uses a four-level classification: L0 parameter → L1 minor template → L2 major template → L3 contract change; any change to graph edges is L2 and requires full regression.
- Prefer inline edits over file regeneration when fixing workflow files — show changes as inline edits to avoid overwriting manual changes made directly in the Dify interface.
