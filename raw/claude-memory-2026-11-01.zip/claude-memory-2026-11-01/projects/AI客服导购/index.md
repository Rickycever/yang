---
name: "AI客服导购"
description: "AI客服导购 — AI-native private domain 导购 platform for brand clients on 企微, built on Dify/ChatFlow."
---

