---
name: "overview"
description: "AI-native private domain shopping guide (导购) platform — purpose, positioning, architecture, clients, and current workstreams"
---

## Purpose & positioning

- Ricky is a founder or senior leader building an AI-native private domain shopping guide (导购) infrastructure platform, transitioning from a human-staffed operation with deep expertise in mother-and-infant and beauty/cosmetics verticals.
- Core strategic thesis: human 导购 operations generate a structural advantage over pure technology vendors — self-generated real conversation data (not purchased corpora), validated SOPs, and domain judgment that constitutes verifiable criteria ("判据") rather than mere data.
- The company occupies both the operator role (running human 导购 teams) and the technology vendor role (delivering AI infrastructure); this dual position is central to its competitive differentiation.
- Competitive positioning uses a two-axis matrix (autonomy level × regulatory intensity) to differentiate from generic AI sales agent vendors.

## Clients and channels

- Serves brand clients operating in enterprise WeChat (企微) private domain channels, with Douyin as an upstream acquisition channel in some deployments.
- Named brand clients include Aptamil, Mead Johnson, Estée Lauder, and Sulwhasoo.

## Key people

- A colleague named "kiki" has built parallel workflow test versions.
- An internal FDE (Forward Deployed Engineer) team handles client onboarding and delivery.

## Platform architecture

- "活知识库" (Living Knowledge Base) is designed as a "frozen core plus programmable shell".
- The human-AI collaboration layer produces three signal types: preference labels, quality labels, and result labels.
- Harness / Agentic ChatFlow serves as the orchestration runtime.
- ChatRAG is the retrieval and output engine.
- Chat3 is the BA terminal.
- MA is the proactive outreach engine.

## Current state — client delivery

- A comprehensive Estée Lauder proposal has been developed (12 sections plus a standalone supplement), covering voice tagging and outlet store AI enablement.
- Three EL proposal items remain unresolved pending confirmation: brand authorization for Sulwhasoo, transfer-to-human rate by category, and conversation data volume framing.
- Estée Lauder can be named directly in materials — no anonymization required.

## Current state — workflow infrastructure

- The production Dify workflow `母婴智能导购V1_Ricky.yml` is the current implementation baseline: 33 nodes, validated as structurally sound.
- Key workflow components include intent convergence summarization (`意图收敛整理`), a code risk gate for legal/medical escalation, and an output-side guardrail layer.
- Known issue: four knowledge bases have no similarity score thresholds set.
- Known issue: HTTP nodes lack an error fallback strategy, causing broken sessions on failure.
- Known issue: Gate 03 (output-side guardrail) is designed but not yet live.

## Current state — demo materials

- A Douyin/企微 AI customer service demo page (V1.1) has been built, with a human-AI collaboration module and a tuning/fix-log module showing real pre-launch issues under conservative verification status framing.

## On the horizon

- Resolve the three pending EL proposal items (Sulwhasoo authorization, transfer-to-human rate, data volume framing).
- Productize the configuration console into a SaaS-style interface for multi-brand client onboarding.
- Apply EnvHarness (Google Research, August 2025) Setup/Rule/Link component decomposition and "verifier immutability" principles to the knowledge base and tool asset layers.
- Proactive repurchase reminder (MA outreach) is on the roadmap as a future capability.
- Add HTTP node error fallback strategies and knowledge base similarity score thresholds to the production workflow.
