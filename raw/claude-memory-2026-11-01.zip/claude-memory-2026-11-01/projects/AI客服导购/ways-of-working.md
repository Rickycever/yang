---
name: "ways-of-working"
description: "Output style, visual standards, review cadence, and the tool/platform stack for this project"
---

## Output and communication style

- Output style is formal written Chinese — no colloquial phrasing; concise professional language accessible to both business and technical audiences.
- Aim for a balance between Accenture-style strategic consulting framing and IT-consulting-level technical specificity.
- Visual design standards: violet/white palette, hard edges, no rounded corners.

## Working patterns

- Ricky consistently reviews recommendations before execution, narrows scope deliberately, and drives multiple rounds of refinement rather than accepting first-pass outputs.
- Verification conservatism: deliberately avoids 100% pass claims in client-facing materials; prefers "fixed but pending second-round validation" framing over overstating confidence.
- Knowledge crystallization: periodically synthesizes learnings into reusable team documents for cross-project knowledge transfer.
- Demo/prototype discipline: fabricated dialogue and unverified capabilities are explicitly excluded from client-facing materials; demo content must map to actual delivered functionality.

## Tools and resources

- Workflow orchestration: Dify — referred to as "ChatFlow" in all client-facing materials — with workflows expressed as YAML DSL files.
- Client-facing channels: enterprise WeChat (企微) and Douyin.
- CMS/API: the chatbuyer platform (`cms.chatbuyer.cn`); key endpoints include `queryNotOrdered` and `queryOrdered`, authenticated with `clientId`/`clientSecret`.
- LLM providers: Volcengine/Doubao (火山方舟/豆包) confirmed available; DeepSeek used in some contexts.
- Architecture reference: the EnvHarness paper (Google Research, August 2025) for component decomposition patterns.
- Delivery format: lightweight HTML file delivery preferred over hosted infrastructure for demos and tools; PowerPoint for executive-facing decks.
