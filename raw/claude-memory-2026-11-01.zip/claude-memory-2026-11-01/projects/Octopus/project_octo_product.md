---
name: "Octo 产品核心机制"
description: "Octo AI-native 协作 OS 的核心机制设计，覆盖事项、品鉴流、Monitor、FileSpace 等"
---

Octo 是一个 AI-native 协作 OS，核心公式 OCTO = Open + Context + Taste + Orchestration，哲学锚点「我品故我在」。

## 核心对象与机制

**事项（Item）** = 一条被赋予结构化骨架的顶层消息，承载：目标/状态/归属链/品鉴信号流/执行载荷。四条创建路径：人主动建、消息转化（Cmd+K）、龙虾提议、Playbook 自动生成。最小信息集：标题 + 认领方即可创建。

**品鉴流** = Agent 做完推到 in_review → 人给信号（通过/批注/驳回/Cmd+K深反馈）→ 信号 append-only 永久留档 → 龙虾下次执行时读取。品鉴历史是 Taste Profile 的原始数据，全自动归档，无需二次审批。驳回事项回到 in_progress 重做；代理龙虾可在授权范围内代理品鉴。

**事项与 Channel/Thread 关系**：Channel 和 Thread 都可以容纳事项和消息。Thread 里挂事项（不是反过来）。Channel 级事项偏"主动布置"，Thread 级事项偏"从讨论收敛"。事项内部可有子事项（多层 Agent 编排），在右侧面板展开，不出现在对话流。事项和 Thread 双向互生：事项可以触发 Thread 讨论，Thread 可以收敛成事项。

**Context 与 FileSpace**：FileSpace 是仓库（持久、结构化、人管理），Context 是工作包（任务级临时、龙虾组装）。FileSpace → Context 靠语义检索，Context → FileSpace 靠 Curation 步骤（龙虾提议，人审批）。Context 管理的核心难题是检索策略（拉什么），不是存储。

**Context 管理工作流（四阶段）**：积累（Agent Memory 自动流水账）→ 提议（龙虾生成 Memory Digest，每次≤5条）→ 筛选（人审批，单条≤10秒）→ 归档（写入 FileSpace）。四类信息归档逻辑不同：品鉴历史全自动，工作产出需确认，知识洞察必须人审，上下文文件人主动上传。

**Monitor 监控室**：Human-in-the-loop 的 A2A 管理界面，坐落在人与 Agent 执行层之间。数据来源是 Agent 主动写进事项的内容（非探针），解决"不把用户当肉鸡"的架构悖论。Zoom 0（Workspace 全局）→ Zoom 1（龙虾编排）→ Zoom 2（CC Terminal 实时）→ Zoom 3（产出物 Diff）。Monitor 是可选关口（过程介入），品鉴是必选关口（最终验收）。高风险场景（耗时长/Token超预算/外部写操作）Monitor 应作为强 checkpoint。

## 三类角色颜色系统
- 人（Human）：紫色
- 长记忆 Agent（龙虾/OpenClaw）：琥珀色
- Runtime Agent（CC-01/CC-02 等）：蓝色

## Why
**How to apply:** 在产品设计讨论中，以这些机制作为基础共识，直接进入设计细节而无需重新解释基础概念。Ricky 已经理解了核心架构。
