---
name: "Octo 产品文档位置"
description: "Octo 产品相关文档的存储路径和文件索引"
---

## 核心文档目录
`/Users/ricky/Documents/octo产品/BG_TOPdown/`

- `00-战略背景与产品哲学基底.md` — 产品哲学、OCTO字母含义、龙虾矩阵、数据护城河、GTM
- `01-Dual-Native-Design-v1.5-洁净版-tikz.md` — GUI 设计蓝图、Dual-Native 架构、四平台策略、多 CC 协作模式
- `octo-concept-architecture-v11.2.md` — 系统架构 v11.2，四大系统（Auth/Octo IM/OpenClaw/ClawHub）、四平台、部署拓扑、九大架构原则
- `11-事项(Item)设计-v2.md` — 事项完整设计：定义、UI 三形态、生命周期、层级结构、Agent 协议
- `lobster-business-ethics-guide-v2.5.md` — 龙虾伦理学：三律、三层义务架构、Skill IP、转型正义（29,862 tokens，需分块读取）
- `octo-product-vision-20260427.md` — 产品战略补充：Runtime Agent vs 长记忆 Agent 成本对比、三方协作模型、A2A 管理 GUI

## 讨论笔记
`/Users/ricky/Documents/octo产品/octo-核心机制讨论笔记.md` — 2026-04-27 讨论整理，覆盖事项创建、品鉴流、对象关系、Context管理、Monitor 六个机制
