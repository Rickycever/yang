---
name: "learnings"
description: "Domain and technical learnings — AI's role in video production, overseas SOP divergences, and Astra/tooling implementation gotchas"
---

## Domain learnings

- AI's highest-value zones in video production are scriptwriting (batch Hook generation, multilingual localization) and post-production (subtitles, format adaptation)
- Three steps must remain human-led: creative angle selection, native-speaker audio review, final visual QA
- Overseas vs. domestic SOP differences center on multilingual localization, digital avatar usage replacing local talent, RTL subtitle handling, and language-segmented attribution
- Arabic requires special handling: RTL subtitles and dialect variation (MSA vs. Gulf vs. Egyptian) need dedicated treatment
- Product sequencing for AIGC tooling: starting with image generation before video reduces complexity, while shared data structures preserve the upgrade path
- Supplier pricing architecture: rate cards and WBS-based costing are needed to establish pricing floors before external quoting

## Technical learnings (Astra / tooling sessions)

- Standalone HTML files with Chinese content require explicit UTF-8 charset declarations
- Platform CSS variables (e.g. `--color-background-primary`) don't resolve outside claude.ai
- Large Chinese-language files cannot be written via a single heredoc execution in bash — use the `create_file` tool instead, then execute with `node build.js`
- Notion API: `notion-create-pages` requires parent as `{'type': 'page_id', 'page_id': '<uuid>'}` with dashes
- Notion API: search before creating to avoid duplicates; child pages must reference exact page IDs from prior creation calls
