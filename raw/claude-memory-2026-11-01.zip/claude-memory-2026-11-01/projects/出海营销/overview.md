---
name: "overview"
description: "Purpose, scope, and current state of Ricky's AI creative production and performance marketing work — read first"
---

## Purpose & context

- Ricky works at the intersection of AI-powered creative production and performance marketing
- Operates as a business leader heading an effects creative division at an advertising agency
- Manages a network of 200+ creative production suppliers
- Focus areas span Meta/Google advertising, short-form video, Chinese e-commerce (出海/overseas marketing), and AI-driven creative tooling
- Core strategic goals: optimizing creative production costs, building internal AI tooling that can evolve into external-facing SaaS, and systematizing creative workflows at scale
- Primary platforms of interest: Meta (Advantage+, Reels, DCO), Google (PMax), Douyin, Xiaohongshu
- Key markets include international/overseas campaigns with multilingual and RTL requirements
- Deep fluency in performance marketing and Martech terminology (Hook率、VTR、CPM、ROAS、CPA、UGC、DTC、VOC); technical practitioner knowledge, not just strategic familiarity

## Current state

- "Astra" merchant task pipeline: a four-node AI-driven content distribution prototype for Chinese e-commerce merchants — Brief parsing → content production → ad placement preparation → data review
- Astra is prototyped as an interactive HTML widget (astra_final_complete_v2); full design documentation stored in Notion (main page + four child pages); a validated PRD Word document (astra_PRD.docx, 6 chapters) has been generated and delivered
- Meta ad creative deconstruction system: building a systematic methodology to analyze high-performing Meta video ads and extract reusable structural script templates
- A three-layer toolchain architecture has been designed for the deconstruction system (data collection → AI analysis → output/template management), orchestrated with n8n/Make
- AIGC internal tooling: developing an AI creative generation and ad management tool with a phased roadmap (internal tooling first → external SaaS)
- Initial AIGC phase prioritizes image generation; brand asset libraries and script templates are being designed with shared data structures for both image and video generation

## Operational pain points

- Creative projects running at a loss due to pricing without proper cost foundations
- Unlimited revision cycles eroding margins
- Competitor agencies approaching the same supplier network with different pricing, which surfaces to clients and creates sales disadvantages

## On the horizon

- Evolving the AIGC internal tool toward an external SaaS product targeting domestic brands' Meta investment teams and agencies
- Continued iteration on the Astra prototype, potentially resolving standalone HTML delivery constraints
- Building out the Meta ad creative template library as a Notion/Airtable database accessible to creative teams
