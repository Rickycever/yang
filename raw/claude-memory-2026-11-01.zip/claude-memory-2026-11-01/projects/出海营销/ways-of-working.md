---
name: "ways-of-working"
description: "Ricky's preferred output style and delivery patterns, plus the tool and resource stack in use"
---

## Approach & patterns

- Strongly prefers conclusion-first, structured outputs with quantified recommendations over theoretical frameworks
- Consistently pushes for immediately actionable, tool-level detail alongside strategic framing
- Favors visually structured deliverables: SVG diagrams, interactive HTML widgets, filterable tables, color-coded phase systems
- Uses phased/iterative delivery — designs systems modularly so internal tools can evolve into external products
- Engages in deep, multi-turn technical work sessions where scope expands progressively through the conversation

## Tools & resources

- Ad intelligence & collection: Meta Ad Library, Minea, BigSpy, Apify/Playwright
- AI video & creative: HeyGen (Video Translation + script-first modes), Runway, Pencil AI, Motion App, Smartly.io
- AI analysis: Whisper / AssemblyAI (transcription), Claude API (batch tagging with structured JSON output), Python/pandas (clustering)
- Workflow automation: n8n, Make
- Documentation & templates: Notion (database views for creative teams), Airtable, DOCX generation via Node.js (`docx` npm package)
- Validation: `/mnt/skills/public/docx/scripts/office/validate.py`
- Persistent outputs: `/home/claude/prd/astra_PRD.docx`
