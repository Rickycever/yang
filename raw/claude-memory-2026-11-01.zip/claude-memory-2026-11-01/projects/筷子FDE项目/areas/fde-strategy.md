---
name: "fde-strategy"
description: "筷子 FDE LAB 的定位与客户选择标准（Ricky 的表述）— Harness 组合原子能力、可运行的视频商业生产系统、KP 积分飞轮"
---

- FDE LAB 定位：基于筷子科技原子能力的 Harness 组合，帮助客户部署一套可运行的视频商业生产系统，基于数据反馈迭代和优化
- 客户选择标准：有明确成功的 SOP、有相关 KPI 和负责人、可以持续消耗筷子 KP 积分，形成 token 经济的飞轮
- FDE 交付方法论 K.U.A.I.Z.I 英文全称：Kickoff（活动策略）、Unit Goals（目标拆解）、Angle（选题策划）、Insight（爆款解析）、Zero-to-Scale（规模复制）、Ignite & Iterate（引爆迭代）
