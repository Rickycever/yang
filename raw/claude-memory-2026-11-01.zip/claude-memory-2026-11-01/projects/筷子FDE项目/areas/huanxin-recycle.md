---
name: "huanxin-recycle-project"
description: "焕新回收内容中台 — 本 Project 内的补充决策（主档见账户级 huanxin-recycle）"
---

- 内容中台要分阶段做；第一阶段聚焦素材管理、生成和基础 KOC 分发（2026-10-19）
- 相关：[[material-asset-center]]
- 生成时库内没有的镜头要自动用 AI 生成补充；采纳建议：只对允许 AI 生成的段落补，验机/报价/到账等实拍段转补拍（2026-10-19）
