---
name: "kp-workspace"
description: "客户自有 harness 接入 KP MCP 时配套的 GUI 上下文中台（KP Workspace）— Ricky 的版本规划决定"
---

- Ricky 在设计客户用 WorkBuddy 等自有 harness 接入筷子 KP MCP 时配套的 GUI 上下文中台（KP Workspace）
- 先简化：V1 只做素材生产和管理，且做通用生产（不限场景）；V2 做 KOC 分发或千川投流
- 相关：[[fde-strategy]]、[[material-asset-center]]
- 除了 WorkBuddy 接入，还要保留一个 GUI 工作流（两种入口并存）
- Workspace 素材标签要参考之前讨论的镜头资产库（[[shot-library-skill]]）的标签体系
- V1 标签决定：B 类（主体/场景/动作）用通用取值；不要“用途”维度；V1 先简化审核规则
- 决定把焕新回收（[[huanxin-recycle]]）等客户内容中台的做法融合进 Workspace 后续版本；V1 仍先简单推进，验证最小闭环
- 修正：Workspace 不针对具体客户设计，而是抽象客户需求、按通用中台分阶段规划；当前最急的是 MCP 服务接入 Agent 后要有一个地方承载上下文
