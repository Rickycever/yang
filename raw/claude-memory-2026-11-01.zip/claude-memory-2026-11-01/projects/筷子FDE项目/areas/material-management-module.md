---
name: "material-management-module"
description: "素材管理模块 — Ricky 在设计的通用素材管理能力（AI 自动打标、客户自定义标签、支撑分镜头召回与视频数据分析）"
---

- Ricky 想好好设计素材管理模块，认为现在普遍客户都有这个需求：标签需 AI 自动打、客户可自定义标签，标签关系到后续分镜头召回查找和生成视频的数据分析
- 相关：[[shot-library-skill]]
