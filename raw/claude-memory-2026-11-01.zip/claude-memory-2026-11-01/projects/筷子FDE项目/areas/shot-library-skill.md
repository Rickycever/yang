---
name: "shot-library-skill"
description: "分镜头素材库管理 skill（shot-library）— Ricky 想把分镜头入库、标签、脚本匹配做成 skill，给 FDE 用；起源于三棵树分镜头复用讨论"
---

- Ricky 手上有很多历史上用过和没用过的分镜头，希望未来能继续复用（讨论起于 [[sankeshu-dealer-content]] 的预设拆解，关联 [[industry-preset-library]]）
- 想围绕分镜头素材库管理创建 skill（使用管理、标签管理、脚本匹配）
- 该 skill 给 FDE 用
- 目前暂时还没有在用的素材管理系统或平台素材库
