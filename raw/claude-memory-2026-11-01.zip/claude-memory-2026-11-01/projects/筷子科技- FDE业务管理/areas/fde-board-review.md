---
name: "fde-board-review"
description: "How FDE projects are reviewed internally at 筷子 — board review format and what the project team vs board sees"
---

- FDE projects go through internal board review; board wants a simplified, multi-project side-by-side comparison table with only key evaluation info for quick decisions and推进 (2026-09)
- The full 立项评估表 circulates only within the project team for alignment, not to the board
- Related: [[fde-strategy]], [[sankeshu-client]]
