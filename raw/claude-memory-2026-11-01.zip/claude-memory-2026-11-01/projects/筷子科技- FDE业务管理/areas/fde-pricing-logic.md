---
name: "fde-pricing-logic"
description: "筷子 FDE 报价逻辑表 — Ricky 维护的 KP 定价方案，对标火山 MediaKit 与自有供应链，含视频分发"
---

- Ricky 在迭代「筷子FDE报价逻辑」表（按 KP 定价，对标火山 MediaKit 与筷子自有供应链成本，关联 [[fde-strategy]]）；已决定把视频分发纳入筷子报价
