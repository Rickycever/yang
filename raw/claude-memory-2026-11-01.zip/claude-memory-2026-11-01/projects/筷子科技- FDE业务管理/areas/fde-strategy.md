---
name: "fde-strategy"
description: "筷子 FDE 战略（项目内补充）— Harness + Skill 的 AI Native 交付定位仍是设想，用于扩大技术影响力与获客"
---

- 用 Harness + Skill 方式交付案例（AI Native 实践）目前只是设想、尚未实践；想先用这个概念做 positioning，扩大技术影响力和获客（2026-09）
- 能力状态（2026-10）：爆款解析复制已上线；视频剪辑、混剪、生成在内测中；可以对外招募 Skill 共创伙伴
- 想给筷子的能力输出模块（Skill、MCP、行业 know-how、Token 网关，作为给视频商业客户的 harness 环境，也可输出 GUI 或视频版 agent harness）取一个独立的技术感名称（2026-10）；已选定名称 Kuaizi RIG（2026-10）
