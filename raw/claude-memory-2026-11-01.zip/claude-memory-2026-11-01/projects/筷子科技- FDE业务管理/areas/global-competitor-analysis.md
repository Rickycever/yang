---
name: "global-competitor-analysis"
description: "筷子全球竞争对手分析 — Ricky 正在做的全球范围竞品研究，已看过 Higgsfield"
---

- Ricky 正在做筷子在全球范围内的竞争对手分析；Higgsfield 是其中已调研的一家（要求从客户、公司本身、资本市场等视角分析，并出给管理层汇报的一页纸）
