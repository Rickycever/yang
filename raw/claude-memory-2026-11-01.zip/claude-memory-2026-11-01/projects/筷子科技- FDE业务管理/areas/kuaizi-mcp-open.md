---
name: "kuaizi-mcp-open"
description: "筷子 MCP 对第三方 agent 开放的方向 — 整包服务 vs 原子能力的取舍，关联 WorkBuddy 接入与 Higgsfield MCP 参照"
---

- Ricky 同意筷子 MCP 对第三方 agent 开放「整包服务」（而非原子能力）；关注点是视频长程任务下如何平衡用户体验，并以 Higgsfield 的 MCP 做法供技术团队借鉴（2026-10，关联 [[workbuddy-open-platform]]、[[global-competitor-analysis]]）
