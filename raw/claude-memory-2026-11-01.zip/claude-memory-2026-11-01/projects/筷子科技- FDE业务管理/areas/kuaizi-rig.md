---
name: "kuaizi-rig"
description: "Kuaizi RIG — 筷子能力输出模块（Skill、MCP、行业 know-how、Token 网关）的独立技术品牌，定位为视频商业的 Agent Harness"
---

- Wants Kuaizi's capability output (connector-like module: Skill, MCP, industry know-how, Token gateway) packaged as a harness environment for video-commerce clients, deliverable as a GUI or a video-specific agent harness, under its own technical-sounding name (2026-10)
- Going with the name "Kuaizi RIG"; wants it positioned with a product logic similar to DeepSeek Harness
- Wants an external one-page promo for RIG with a designed logo, without "内测中"-style status labels
- RIG is branded "by FDE LAB" and should follow the FDE LAB logo/visual identity, but the RIG logo must be clearly distinguishable from the FDE LAB logo (felt a too-similar version lacked differentiation)
- Chose the Chinese name "驭帧" for RIG (written "RIG 驭帧 · by FDE LAB") (2026-10)
- RIG also provides video large models itself, helping clients pick the optimal model per task (OpenRouter-like) — models are part of RIG, not external to it
- RIG principles framed as: human taste and judgment (人的 taste 与判断力) plus content traceability and attribution (内容溯源与归因); the core of commercial video is optimizing growth
- RIG's video capabilities (Reel) number 50+
