---
name: "principles"
description: "Load-bearing strategy principles and design rules governing GEO, FDE LAB, and commercial structuring"
---

- Determinism over flexibility: fixed SOPs are not constraints — they are the prerequisite for meaningful iteration and attribution; Ricky consistently pushes for attributability at every layer
- Provenance as foundation: every content piece requires a `provenance` version stamp as the basis for attribution and iteration
- FDE must produce, not just identify: FDE LAB deliverables are light apps and Agent workflows — client identification alone is insufficient
- SRB as GTM gate: light apps become GTM-ready products only when they meet three conditions — making already-successful clients more successful, hitting KP consumption scenarios (multiple KP nodes embedded in the client's SOP), and being independently sellable by sales
- Client tiering for FDE LAB: SKA = 100万以上 custom development and must commit to future token/KP consumption (no commitment = 陷阱区, not SKA); KA/战略客户 = 50–100万; 自助跑量 = 50万以下 sold as API; 生态层 (转包给生态伙伴) deprioritized until 筷子's own atomic capabilities are solid; 特殊类型客户 (上影、传音类, strategic-resource value) held directly by FDE LAB outside the standard tiering
- KP over token as the consumption measure: token generation is only part of KP consumption; what matters is how many KP nodes are embedded in the client's success SOP, not raw volume at one node
- Rule of three (三次法则): scenario SOPs should be promoted into reusable atoms only after appearing three times
- Feedback loop closure is the moat: the 全链路宽表, currently assembled manually, is the mechanism that prevents the FDE model from being displaced by model improvements; automating it is the highest-priority architectural gap
- 补量 (artificial engagement inflation) must be excluded from the data pipeline to preserve signal integrity
- Strategic narrative discipline: the external story has expanded faster than demonstrated capability — prove the model with one real client first
- AI scene value filter (from Winder): high-value scenes must be both Token Heavy and 持续琢磨 (continuously requiring high-frequency re-engagement); FDE should position as "strategy judgment provider," not production executor
- Performance share structuring: contracts should be "guaranteed prepaid credit pack + excess gain-share" rather than pure back-end splits, to protect cash flow
- Irreversible actions stay internal: final version confirmation, CCTV submission, and KOC publishing are explicitly excluded from external tool (MCP) exposure
