---
name: "ways-of-working"
description: "How Ricky works on this project — deliverable conventions, collaboration patterns, tools, and output formats"
---

## Working patterns

- Produces versioned, named deliverables with explicit version tracking (e.g., v1.4, v3.4) across HTML prototypes, flow diagrams, SOPs, and architecture diagrams
- Makes substantive mid-session corrections that reshape designs — steers toward greater precision and pushes back on loose framing
- Strong preference for outputs usable directly in investor-facing materials (BP/pitch deck), with high standards for data sourcing transparency and logical structure
- Requests removal of unverified financial metrics from public-facing materials
- Shares internal artifacts via screenshots when internal URLs are inaccessible to Claude
- Frames product positioning with Chinese-language precision (e.g., "从创造到交易的责任层")
- Evaluates competitors structurally — e.g., LibTV isomorphism analysis with explicit differentiation points and action items
- Uses HTML/JS as the primary format for interactive strategic visualizations, with Python occasionally used for file manipulation

## Tools and resources

- Internal platforms: kclaw capability catalog, WorkBuddy (orchestration layer candidate), Feishu (wiki and collaboration)
- Production: Seedance 2.0
- Model vendors of interest: MiniMax H3 (cost routing, brand text/logo rendering, V2V motion transfer)
- Distribution: CCTV.com API, KOC account matrix
- External orchestration: WorkBuddy (MCP connector, phase two)
- Output formats: HTML interactive visualizations (base64-encoded blob URLs), Word documents, Excel workbooks, Markdown SOPs
- FDE projects go through an internal board review; board wants a simple one-table cross-project comparison with only key evaluation info for quick decisions, while the full 立项评估表 is circulated only within the project team (2026-09)
