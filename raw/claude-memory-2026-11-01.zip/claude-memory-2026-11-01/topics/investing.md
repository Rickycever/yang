---
name: "investing"
description: "Ricky's retail investing activity, markets, and approach"
---

- Active retail investor in A-share and Hong Kong equity markets
- Familiar with options mechanics, tax optimization strategies, and trading tools
- Engages in portfolio-level thinking across sectors
- Received a full portfolio diagnostic with recommendations around concentration risk and disposition effect
- Analyzed Hong Kong IPO lock-up expiry opportunities (大族数控, 东鹏饮料, 澜起科技) and developed conditional order strategies
- Managed the exercise and trading of stock options in Minglue Technology (02718.HK) around the lock-up expiry, including a split exercise strategy, Stock Connect arbitrage, and tax optimization analysis
