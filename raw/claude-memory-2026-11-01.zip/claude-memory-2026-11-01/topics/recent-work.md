---
name: "recent-work"
description: "Recent work activity that doesn't rise to a standalone project"
---

- Preparing investor-facing roundtable materials on enterprise AI adoption, AI Agent trends, and Kuaizi's Agentic Service practice
- Prepared a user growth AI transformation livestream with research on NIO and KFC/Yum China cases, CLV frameworks, and GEO/Agentic Commerce trends
- Longstanding involvement with Minglue Technology's organizational and product ecosystem: analyzed their AI agent product Mano-P, processed Eli Lilly RFPs, built Mengniu advertising system architecture diagrams, worked on the BCM marketing operations platform
- Worked on enterprise vendor responses (Haidilao procurement AI, multi-agent architecture)
- Prototype development for tools like "astra" and "Booming," and tourism AI dashboard cloning projects
- Worked on harness engineering concepts for video generation architecture, producing structured documentation and SVG diagrams
