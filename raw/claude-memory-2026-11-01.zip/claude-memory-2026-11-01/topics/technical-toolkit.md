---
name: "technical-toolkit"
description: "Tools and technologies Ricky consistently works with"
---

- Technical toolkit consistently includes HTML/JS prototyping, Dify DSL/YAML workflows, Python scripting, Node.js document generation, and Notion MCP integration
- Primarily uses Seedance/Volcano Engine for AI video generation
